<?php
class Unprocured_delivery_material_item_grn_item extends MY_Model{
    const DB_TABLE = 'unprocured_delivery_material_item_grn_items';
    const DB_TABLE_PK = 'id';

    public $unprocured_delivery_material_item_id;
    public $grn_item_id;
}
