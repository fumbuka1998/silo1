<?php

class Payment_voucher_grn extends MY_Model{
    
    const DB_TABLE = 'payment_voucher_grns';
    const DB_TABLE_PK = 'id';

    public $payment_voucher_id;
    public $grn_id;
   
}