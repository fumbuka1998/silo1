<?php

class Imprest_payment_voucher extends MY_Model{
    
    const DB_TABLE = 'imprest_payment_vouchers';
    const DB_TABLE_PK = 'id';

    public $imprest_id;
    public $payment_voucher_id;
   

}

