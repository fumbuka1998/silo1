<?php

class Casual_labour_cost extends MY_Model{
    
    const DB_TABLE = 'casual_labour_costs';
    const DB_TABLE_PK = 'casual_labour_cost_id';
    
    public function actual_cost(){
        return 0;
    }

}

