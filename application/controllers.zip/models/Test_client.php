<?php
/**
 * Created by PhpStorm.
 * User: Kihuna
 * Date: 7/24/2018
 * Time: 8:19 AM
 */

class Test_client extends MY_Model{
    const DB_TABLE = 'test_clients';
    const DB_TABLE_PK = 'id';

    public $name;
    public $sex;
    public $address;


}