<?php

class Imprest_material_item extends MY_Model{
    
    const DB_TABLE = 'imprest_material_items';
    const DB_TABLE_PK = 'id';

    public $imprest_id;
    public $goods_received_note_material_stock_item_id;
   

}

