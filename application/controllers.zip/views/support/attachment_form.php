<?php
/**
 * Created by PhpStorm.
 * User: zeus
 * Date: 30/10/2018
 * Time: 09:32
 */
?>

<div class="modal-dialog modal-md">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body"">

        </div>

        <div class="modal-footer">

        </div>
    </div>
</div>
