
<div class="box-header with-border">
    <div class="col-xs-12">
        <div class="box-tools pull-right">
        </div>
    </div>
</div>
<div class="box-body">
    <div class="row">
        <div class="col-xs-12 table-responsive">
            <table class="table table-bordered table-hover table-striped" contractor_id="<?= $contractor->id ?>" id="sub_contracts_list">
                <thead>
                <tr>
                    <th>Project Name</th><th>Contract Name</th><th>Contract Date</th><th>Added On</th><th>Created by</th><th>Descriptions</th>
                </tr>
                </thead>
            </table>
        </div>
    </div>
</div>