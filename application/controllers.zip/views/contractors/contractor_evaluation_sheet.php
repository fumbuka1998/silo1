<?php
/**
 * Created by PhpStorm.
 * User: use
 * Date: 2/15/2019
 * Time: 3:39 PM
 */

$this->load->view('includes/letterhead');
?>
<h2 style="text-align: center">CONTRACTOR EVALUATIONS</h2>
<br/>
<br/>
<?php
$this->load->view('contractors/contractor_evaluation_table');
?>
