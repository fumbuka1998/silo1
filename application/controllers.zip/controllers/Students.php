<?php

/**
 * Created by PhpStorm.
 * User: stunnaedward
 * Date: 21/03/2018
 * Time: 11:21
 */
class Students extends CI_Controller
{

    public function index(){
        $this->load->view('students/index');
    }

    public function save_student()
    {
        
    }

}
